#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
覆盖配置，即部署到服务器的配置文件
'''

__author__ = 'Mosan'

configs = {
    'db': {
        'host': '127.0.0.1'
    }
}
