#!/usr/bin/env python3
# -*- coding: utf-8 -*-

__author__ ='Mosan'

'''
当部署到远程服务器上时的配置文件
'''

configs = {
    'db': {
        'host': '127.0.0.1',
        'password': 'mysqlmima2018'
    }
}
