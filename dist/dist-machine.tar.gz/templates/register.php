<?php
    header('content-type:text/html;charset= utf-8');
    $str = '{
        "name":"Jason"
    }';
    print_r($str);
?>